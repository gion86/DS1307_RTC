//==========================================================================
//	Author		    	: Howard Lim Chong Han
//	Project	            : RTC with Drift Correction
//	Project description : Sketch to set RTC and calibrate drift correction for DS1307
//                      : uses modified Time and DS1307RTC Library
//==========================================================================
//      Usage           : Open serial Monitor
//
//                      Command to set RTC time and update DriftInfo.DriftStart in the RTC battery back memory
//                      Command format: TYYMMDDHHMMSS
//                      Example: 2012 Oct 21 6:30am is T121021063000
//
//                      Command "I" read DriftInfo from RTC Memory

#include <Time.h>  
#include <Wire.h>  
#include <DS1307RTC.h>  // a basic DS1307 library that returns time as a time_t

tmDriftInfo di;

void setup () {
  Serial.begin(9600);
  setSyncProvider(RTC.get);   // the function to get the time from the RTC
  if(timeStatus()!= timeSet) 
     Serial.println("Unable to sync with the RTC");
  else
     Serial.println("RTC has set the system time");

  di = RTC.read_DriftInfo();
  di.DriftDays = 1000;     // valid value 0 to 65,535
  di.DriftSeconds = 2800;  // fine tune this until your RTC sync with your reference time, valid value -32,768 to 32,767
  RTC.write_DriftInfo(di); // once you're happy with the drift setting you only have to read the DriftInfo and pass it to now2() or now3() function to get your drift corrected time

}

void loop()
{
  if (Serial.available()) {
	  processSerialCommand();
  }
  SerialDisplayDateTime(now3(di))    // use this if you don't have an LCD Display
}

void SerialDisplayDateTime(time_t timeToDisplay){
  Serial.print(year(timeToDisplay)); Serial.print("/");
  Serial.print(monthShortStr(month(timeToDisplay)));Serial.print("/");
  Serial.print(day(timeToDisplay));Serial.print(" ");
  Serial.print(hourFormat12(timeToDisplay));
  printDigits(minute(timeToDisplay));
  printDigits(second(timeToDisplay));
  if (isAM(timeToDisplay)) {
	  Serial.print("AM");
  } 
  else {
	  Serial.print("PM");
  } 
  Serial.print(" ");
  Serial.print(dayStr(weekday(timeToDisplay)));
}

void printDigits(int digits){
  // utility function for digital clock display: prints preceding colon and leading 0
  Serial.print(":");
  if (digits < 10)
    Serial.print('0');
  Serial.print(digits);
}

void processSerialCommand() {
  char c = Serial.read(); 
  switch(c){
    case 'T':
      // Command to set RTC time and update DriftInfo.DriftStart in the RTC battery back memory
      // Command format: TYYMMDDHHMMSS
      // Example: 2012 Oct 21 1:23pm is T121021132300
      delay(100); // Wait for all data to arrive
      if (Serial.available() == 12){  // process only if all expected data is available
        tmElements_t tme;
        time_t newTime;

        // Parse incomming 12 ASCII charaters into time_t
        // no error checking for numeric values in YYMDDHHMMSS fields, so be carefull!
        c = Serial.read(); tme.Year = c - '0';
        c = Serial.read(); tme.Year = 10 * tme.Year; tme.Year += c - '0'; tme.Year += 30;
        c = Serial.read(); tme.Month = c - '0';
        c = Serial.read(); tme.Month = 10 * tme.Month; tme.Month += c - '0';
        c = Serial.read(); tme.Day = c - '0';
        c = Serial.read(); tme.Day = 10 * tme.Day; tme.Day += c - '0';
        c = Serial.read(); tme.Hour = c - '0';
        c = Serial.read(); tme.Hour = 10 * tme.Hour; tme.Hour += c - '0';
        c = Serial.read(); tme.Minute = c - '0';
        c = Serial.read(); tme.Minute = 10 * tme.Minute; tme.Minute += c - '0';
        c = Serial.read(); tme.Second = c - '0';
        c = Serial.read(); tme.Second = 10 * tme.Second; tme.Second += c - '0';
        newTime = makeTime(tme);
        RTC.set(newTime);   // set the RTC and the system time to the received value
        setTime(newTime);

        tmDriftInfo diUpdate = RTC.read_DriftInfo();  // update DriftInfo in RTC
        diUpdate.DriftStart = newTime;
        RTC.write_DriftInfo(diUpdate);

        Serial.print("RTC Set to: "); 
		SerialDisplayDateTime(newTime);
      }
      break;
    case 'I':
      // read and display DriftInfo from RTC memory
      tmDriftInfo diRead = RTC.read_DriftInfo();
      if (diRead.DriftStart == 0 | diRead.DriftDays == 0 | diRead.DriftSeconds == 0) {
        Serial.println("DriftInfo not set yet!");
        break;
      }
      Serial.println("*** DriftInfo Read from RTC Memory ***");
      Serial.print("DriftStart   : ");
      SerialDisplayDateTime(diRead.DriftStart); 
	  Serial.println();
      Serial.print("DriftDays    : ");
      Serial.println(diRead.DriftDays);
      Serial.print("DriftSeconds : ");
      Serial.println(diRead.DriftSeconds);
      Serial.print("Day(s) since drift start: ");
      Serial.println(float(now() - diRead.DriftStart) / float(SECS_PER_DAY));
      long tmp = now() - diRead.DriftStart;
      tmp *= diRead.DriftSeconds;
      Serial.print("Your RTC has Drifted(seconds): ");
      Serial.println(float(tmp) / float(SECS_PER_DAY * diRead.DriftDays));
      break;
  }
  
  while (Serial.available()) { 
	  Serial.read(); 
  } // clear serial buffer
}